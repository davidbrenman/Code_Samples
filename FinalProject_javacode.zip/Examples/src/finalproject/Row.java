package finalproject;

public class Row {
	private String code_year;
	private String country;
	private String code;
	private Integer year;
	private Double gdp;
	private Double emissions;
	private Double renewable;
	
	//full constructor
	public Row(String code_year, String country, String code, Integer year, Double gdp, Double emissions, Double renewable) {
		this.code_year = code_year;
		this.country = country;
		this.code = code;
		this.year = year;
		this.gdp = gdp;
		this.emissions = emissions;
		this.renewable = renewable;
	}
	
	//constructor without emissions*
	public Row(String code_year, String country, String code, Integer year, double gdp, double renewable) {
		this.code_year = code_year;
		this.country = country;
		this.code = code;
		this.year = year;
		this.gdp = gdp;
		this.emissions = null;
		this.renewable = renewable;
	}
	
	//constructor without renewable*
	public Row(String code_year, String country, String code, Integer year, Double gdp, Double emissions) {
		this.code_year = code_year;
		this.country = country;
		this.code = code;
		this.year = year;
		this.gdp = gdp;
		this.emissions = emissions;
		this.renewable = null;
	}
	
	//constructor without emissions OR renewable*
	public Row(String code_year, String country, String code, Integer year, Double gdp) {
		this.code_year = code_year;
		this.country = country;
		this.code = code;
		this.year = year;
		this.gdp = gdp;
		this.emissions = null;
		this.renewable = null;
	}
	
	// * not necessary for program to run successfully

	
	//getters and setters
	public String getCode_year() {
		return code_year;
	}

	public void setCode_year(String code_year) {
		this.code_year = code_year;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Double getGdp() {
		return gdp;
	}

	public void setGdp(Double gdp) {
		this.gdp = gdp;
	}

	public Double getEmissions() {
		return emissions;
	}

	public void setEmissions(Double emissions) {
		this.emissions = emissions;
	}

	public Double getRenewable() {
		return renewable;
	}

	public void setRenewable(Double renewable) {
		this.renewable = renewable;
	}
	
	
}
