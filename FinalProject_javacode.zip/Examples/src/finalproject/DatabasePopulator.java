package finalproject;

import java.io.File;
import java.io.FileReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;

import com.opencsv.CSVParser;
import com.opencsv.CSVReader;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import finalproject.Row;

public class DatabasePopulator {

	public static void main(String[] args) throws Exception {
		
		// Load the PostgreSQL driver into your Java program.
		Class.forName("org.postgresql.Driver");
		
		String host = "localhost";
		
		int port = 5432; 
		
		String database = "final project";
		
		String url = "jdbc:postgresql://" + host + ":" + port  + "/" + database;
		
		Properties props = new Properties();
		props.setProperty("user","postgres");
		props.setProperty("password","hdng9383");
		props.setProperty("ssl","false");
		Connection connection = DriverManager.getConnection(url, props);
		
		//read data from file to be inserted into table
		String path = "C:\\Users\\dbren\\Desktop\\SYS2202 Final Project\\FinalProject_data_countries.csv";
		FileReader file = new FileReader(path);
		CSVReader csv = new CSVReader(file, CSVParser.DEFAULT_SEPARATOR, CSVParser.DEFAULT_QUOTE_CHARACTER, 1);
		
		ArrayList<Row> rows = new ArrayList<Row>();
		
		//read first record
		String[] record = csv.readNext();
		
		//while we have a record...
		while (record != null) {
			
			//get fields
			String code_year = record[0];
			String country = record[1];
			String code = record[2];
			Integer year = Integer.parseInt(record[3]);
			Double gdp = Double.parseDouble(record[4]);
			Double emissions = null;
			Double renewable = null;
			if (!record[5].equals("")) {
				emissions = Double.parseDouble(record[5]);
			}
			if (!record[6].equals("")) {
				renewable = Double.parseDouble(record[6]);
			}
			
			
			//create Row object and add to list
			Row row = new Row(code_year, country, code, year, gdp, emissions, renewable);
			rows.add(row);
			
			//get next record
			record = csv.readNext();
		}
		
		csv.close();
		
		//iterate through "rows" ArrayList and insert into PostgreSQL table
		for ( Row row : rows ) {
			
			 //PreparedStatement to temporarily ignore potential null values (emissions and renewable)
			 try( PreparedStatement stmt = connection.prepareStatement("INSERT INTO world_data.finalproject_data (code_year, country, code, year, gdp, emissions, renewable) "
						+ "values (\'" + row.getCode_year() + 
						"\',\'" + row.getCountry() + 
						"\',\'" + row.getCode() + 
						"\',\'" + row.getYear() + 
						"\',\'" + row.getGdp() + 
					 	"\',?, ?)")) {
				 
				//if the value for emissions is null, setNull(). Else, use the true value 
				if ( row.getEmissions() == null ) {
						stmt.setNull(1, java.sql.Types.DOUBLE );				
				}
				else {
					stmt.setDouble(1, row.getEmissions() );
				}
				
				//if the value for renewable is null, setNull(). Else, use the true value 
				if ( row.getRenewable() == null ) {
					stmt.setNull(2, java.sql.Types.DOUBLE );
				}
				else {
					stmt.setDouble(2, row.getRenewable() );
				}
				 
				//execute the above commands
				stmt.executeUpdate();
				
			 }
			
			
		}		
		
	}
}